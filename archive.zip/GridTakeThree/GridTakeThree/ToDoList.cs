﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GridTakeThree {
    class ToDoList {
        /* 
        Things to do:
            Import/Export:
                -Der skal kunne tages højde for fler-etage bygninger
        
        
        
        
        
        
        
        
        
        
        
        
        */
    }
}
